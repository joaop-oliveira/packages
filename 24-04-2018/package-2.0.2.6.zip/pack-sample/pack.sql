select * from banco
